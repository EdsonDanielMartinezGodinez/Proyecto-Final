package com.mycompany.c45project; // O el paquete que estés usando

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet; // Para obtener valores únicos manteniendo el orden de inserción (luego se ordena)
import java.util.List;
import java.util.Map;
import java.util.Set; // Para el LinkedHashSet

public class C45DecisionTree {
    private TreeNode root;

    public void train(List<Map<String, String>> data, List<String> attributes, String target) {
        // Es una buena práctica hacer una copia de la lista de atributos si se va a modificar
        // para no afectar la lista original pasada como argumento.
        List<String> remainingAttributes = new ArrayList<>(attributes);
        root = buildTree(data, remainingAttributes, target);
    }

    public String predict(Map<String, String> instance) {
        if (this.root == null) {
            System.err.println("Error: El árbol no ha sido entrenado. Llama a train() primero.");
            return "Error: Árbol no entrenado.";
        }
        TreeNode node = root;
        while (node != null && !node.isLeaf()) { // Añadir chequeo de node != null
            String attrName = node.attribute;
            if (attrName == null) {
                // Esto podría pasar si un nodo de decisión no tiene un atributo asignado correctamente.
                System.err.println("Error en predicción: Nodo de decisión sin atributo.");
                return "Error: Nodo inválido en el árbol.";
            }
            String valStr = instance.get(attrName);
            if (valStr == null) {
                // Estrategia simple: devolver un error.
                // Estrategias más avanzadas: intentar seguir la rama más probable,
                // o devolver la clase mayoritaria del nodo actual si se almacenara.
                return "❌ Valor faltante para el atributo: " + attrName;
            }
            try {
                double val = Double.parseDouble(valStr.trim());
                node = (val <= node.threshold) ? node.left : node.right;
            } catch (NumberFormatException e) {
                return "❌ Valor '" + valStr + "' para atributo '" + attrName + "' no es numérico.";
            }
        }
        if (node == null) {
             // Si llegamos aquí, algo fue mal en la navegación o construcción del árbol
            System.err.println("Error en predicción: Se alcanzó un nodo nulo inesperadamente.");
            return "Error: Ruta de predicción inválida.";
        }
        return node.label;
    }

    private TreeNode buildTree(List<Map<String, String>> data, List<String> attributes, String target) {
        // Caso base 1: Datos vacíos
        if (data == null || data.isEmpty()) {
            // En C4.5 original, si es vacío, se crea una hoja con la clase mayoritaria del padre.
            // Aquí, no tenemos al padre directamente. Devolver null o una etiqueta por defecto.
            // Devolver null podría ser problemático si no se maneja en la recursión.
            // Por ahora, para evitar NullPointerExceptions en la construcción de la hoja:
            System.err.println("Advertencia: Subconjunto de datos vacío en buildTree. Se creará nodo hoja con etiqueta 'Desconocido (datos vacíos)'.");
            TreeNode leaf = new TreeNode(); // Asumiendo que TreeNode tiene un constructor por defecto
            leaf.label = "Desconocido (datos vacíos)";
            return leaf;
        }

        // Caso base 2: Todos los ejemplos en data tienen la misma clase
        if (allSameClass(data, target)) {
            TreeNode leaf = new TreeNode();
            leaf.label = data.get(0).get(target);
            return leaf;
        }

        // Caso base 3: No quedan atributos para dividir
        if (attributes.isEmpty()) {
            TreeNode leaf = new TreeNode();
            leaf.label = majorityClass(data, target);
            return leaf;
        }

        String bestAttr = null;
        double bestGainRatio = -1.0; // Usar -1.0 para asegurar que cualquier ratio positivo sea mejor
        double bestThreshold = 0.0;

        for (String attr : attributes) {
            double[] result = gainRatio(data, attr, target); // Llamada al método gainRatio corregido
            if (result[0] > bestGainRatio) {
                bestGainRatio = result[0];
                bestThreshold = result[1];
                bestAttr = attr;
            }
        }

        // Caso base 4: No se encontró un buen atributo para dividir (ej. gainRatio <= 0)
        // O si bestAttr sigue siendo null (ningún atributo dio ganancia positiva)
        if (bestAttr == null || bestGainRatio <= 0) {
            TreeNode leaf = new TreeNode();
            leaf.label = majorityClass(data, target);
            return leaf;
        }

        TreeNode node = new TreeNode();
        node.attribute = bestAttr;
        node.threshold = bestThreshold;

        List<Map<String, String>> leftData = new ArrayList<>();
        List<Map<String, String>> rightData = new ArrayList<>();

        for (Map<String, String> row : data) {
            String valStr = row.get(bestAttr);
            if (valStr != null && !valStr.trim().isEmpty()) { // Robustez aquí también
                try {
                    double val = Double.parseDouble(valStr.trim());
                    if (val <= bestThreshold) {
                        leftData.add(row);
                    } else {
                        rightData.add(row);
                    }
                } catch (NumberFormatException e) {
                    // Si un valor no es parseable para el bestAttr, se podría ignorar la fila
                    // o asignar a una rama por defecto, o lanzar un error.
                    // Por consistencia con gainRatio, lo ignoramos aquí.
                    System.err.println("Advertencia en buildTree (división): Valor '" + valStr + "' para el atributo '" + bestAttr + "' no es numérico. Fila ignorada para división.");
                }
            } else {
                // Manejo de nulos para el bestAttr al dividir los datos.
                // C4.5 tiene varias estrategias:
                // 1. Distribuir la instancia a todas las ramas con pesos.
                // 2. Enviar a la rama más común.
                // 3. Ignorar la instancia. (Lo que hacemos aquí implícitamente)
                // System.err.println("Advertencia en buildTree (división): Valor nulo/vacío para el atributo '" + bestAttr + "'. Fila ignorada para división.");
            }
        }
        
        // Si una de las divisiones resulta vacía, no es una buena división.
        // En este caso, el nodo actual se convierte en una hoja con la clase mayoritaria.
        if (leftData.isEmpty() || rightData.isEmpty()) {
            node.attribute = null; // Ya no es un nodo de decisión
            node.threshold = 0.0;
            node.label = majorityClass(data, target); // Usar 'data', no leftData o rightData
            node.left = null;
            node.right = null;
            return node;
        }


        List<String> newAttrs = new ArrayList<>(attributes);
        newAttrs.remove(bestAttr); // El atributo ya fue usado

        node.left = buildTree(leftData, newAttrs, target);
        node.right = buildTree(rightData, newAttrs, target);
        
        // Si los hijos son nulos (por ejemplo, porque los subconjuntos resultantes eran vacíos
        // y buildTree devolvió la hoja "Desconocido (datos vacíos)"),
        // este nodo podría no ser útil como nodo de decisión.
        // Sin embargo, el caso base de leftData/rightData vacíos ya convierte el nodo actual en hoja.

        return node;
    }

    private boolean allSameClass(List<Map<String, String>> data, String target) {
        if (data.isEmpty()) {
            return false; // O true, dependiendo de la semántica deseada. Considerar false para evitar errores.
        }
        String firstLabel = data.get(0).get(target);
        if (firstLabel == null) { // Si la primera etiqueta es null, ¿son todas null?
            for (Map<String, String> row : data) {
                if (row.get(target) != null) return false;
            }
            return true; // Todas son null
        }
        for (Map<String, String> row : data) {
            if (!firstLabel.equals(row.get(target))) {
                return false;
            }
        }
        return true;
    }

    private String majorityClass(List<Map<String, String>> data, String target) {
        if (data == null || data.isEmpty()) {
            return "Desconocido (mayoría)"; // Etiqueta por defecto si no hay datos
        }
        Map<String, Integer> count = new HashMap<>();
        int nullCount = 0;
        for (Map<String, String> row : data) {
            String label = row.get(target);
            if (label != null) {
                count.put(label, count.getOrDefault(label, 0) + 1);
            } else {
                nullCount++;
            }
        }

        if (count.isEmpty()) {
            // Todos los valores de la clase objetivo eran null, o la lista de datos estaba vacía.
            return "Desconocido (sin etiquetas)";
        }
        
        // Encontrar la clase mayoritaria entre las no nulas
        String majority = null;
        int maxCount = -1;
        for(Map.Entry<String, Integer> entry : count.entrySet()){
            if(entry.getValue() > maxCount){
                maxCount = entry.getValue();
                majority = entry.getKey();
            }
        }
        // Opcional: si los nulos son más comunes que cualquier clase, podrías tener una lógica diferente.
        // Por ahora, devolvemos la mayoría de las clases no nulas.
        return majority;
    }

    private double entropy(List<Map<String, String>> data, String target) {
        if (data == null || data.isEmpty()) {
            return 0.0;
        }
        Map<String, Integer> count = new HashMap<>();
        int totalNonNullRows = 0;
        for (Map<String, String> row : data) {
            String label = row.get(target);
            if (label != null) { // Solo considerar filas con etiqueta no nula para el cálculo de entropía
                count.put(label, count.getOrDefault(label, 0) + 1);
                totalNonNullRows++;
            }
        }

        if (count.isEmpty() || count.size() <= 1 || totalNonNullRows == 0) { 
            // Si no hay etiquetas, o solo una clase, o ninguna fila con etiqueta, la entropía es 0.
            return 0.0;
        }

        double entropy = 0.0;
        for (int c : count.values()) {
            double p = c / (double) totalNonNullRows; // Usar totalNonNullRows para la probabilidad
            if (p > 0) { // Evitar log(0)
                 entropy -= p * (Math.log(p) / Math.log(2));
            }
        }
        return entropy;
    }

    // CORREGIDO: Método gainRatio con manejo de nulos y mejoras
    private double[] gainRatio(List<Map<String, String>> data, String attr, String target) {
        List<Double> values = new ArrayList<>();
        for (Map<String, String> row : data) {
            String valStr = row.get(attr); 
            
            if (valStr != null && !valStr.trim().isEmpty()) { 
                try {
                    values.add(Double.parseDouble(valStr.trim())); 
                } catch (NumberFormatException e) {
                    System.err.println("Advertencia en gainRatio: El valor '" + valStr + "' para el atributo '" + attr + "' no es un double válido. Se omitirá.");
                }
            } else {
                // System.err.println("Advertencia en gainRatio: Valor nulo o vacío para el atributo '" + attr + "'. Se omitirá.");
            }
        }

        if (values.isEmpty()) { 
            return new double[]{-1.0, 0.0}; 
        }

        // Usar LinkedHashSet para obtener valores únicos manteniendo el orden de inserción, luego ordenar.
        // O simplemente ordenar y luego iterar de forma que se salten duplicados al crear umbrales.
        // Para C4.5, los umbrales se consideran entre puntos donde la clase cambia.
        // Una forma más simple es ordenar todos los valores y tomar puntos medios.
        Collections.sort(values); 
        List<Double> uniqueSortedValues = new ArrayList<>(new LinkedHashSet<>(values)); // Obtiene únicos y luego se re-ordena si es necesario, aunque sort ya lo hizo.
                                                                                      // Si 'values' ya está ordenado, LinkedHashSet preserva ese orden para los únicos.

        if (uniqueSortedValues.size() < 2) { 
            return new double[]{-1.0, 0.0};
        }

        double bestThreshold = 0.0;
        double bestGainRatio = -1.0; 
        double currentEntropy = entropy(data, target); 

        for (int i = 0; i < uniqueSortedValues.size() - 1; i++) { 
            double threshold = (uniqueSortedValues.get(i) + uniqueSortedValues.get(i + 1)) / 2.0;

            List<Map<String, String>> left = new ArrayList<>();
            List<Map<String, String>> right = new ArrayList<>();

            for (Map<String, String> row : data) {
                String valStr = row.get(attr);
                if (valStr != null && !valStr.trim().isEmpty()) { 
                    try {
                        double val = Double.parseDouble(valStr.trim());
                        if (val <= threshold) {
                            left.add(row);
                        } else {
                            right.add(row);
                        }
                    } catch (NumberFormatException e) {
                        // Ya se manejó/advirtió en el primer bucle
                    }
                }
            }
                
            if (left.isEmpty() || right.isEmpty()) { 
                continue; 
            }

            double pLeft = (double) left.size() / data.size();
            double pRight = (double) right.size() / data.size();

            // Solo calcular entropía si los subconjuntos no son vacíos
            double entropyLeft = (pLeft > 0) ? entropy(left, target) : 0.0;
            double entropyRight = (pRight > 0) ? entropy(right, target) : 0.0;

            double infoGain = currentEntropy - (pLeft * entropyLeft) - (pRight * entropyRight);

            double splitInfo = 0.0;
            if (pLeft > 0) {
                splitInfo -= pLeft * (Math.log(pLeft) / Math.log(2));
            }
            if (pRight > 0) {
                splitInfo -= pRight * (Math.log(pRight) / Math.log(2));
            }

            if (splitInfo == 0) { 
                continue;
            }
            
            double gainRatioValue = infoGain / splitInfo; // Renombrar variable local para evitar confusión con el método

            if (gainRatioValue > bestGainRatio) {
                bestGainRatio = gainRatioValue;
                bestThreshold = threshold;
            }
        }
        return new double[]{bestGainRatio, bestThreshold};
    }

    public void printTree() {
        printTreeRec(this.root, 0);
    }

    private void printTreeRec(TreeNode node, int nivel) {
        if (node == null) {
            // System.out.println("  ".repeat(nivel) + "-> NULL NODE"); // Opcional: para depurar si se llega a nodos nulos
            return;
        }

        String indent = "  ".repeat(nivel); // Usar dos espacios para la indentación

        if (node.isLeaf()) {
            System.out.println(indent + "→ Clase: " + node.label);
        } else {
            // Asegurarse de que el atributo no sea null antes de imprimirlo
            String attributeDisplay = (node.attribute != null) ? node.attribute : "ATRIBUTO_NULO";
            System.out.println(indent + "[ATRIBUTO: " + attributeDisplay + " \u2264 " + String.format("%.2f", node.threshold) + "]"); // \u2264 es ≤
            
            System.out.println(indent + "  ├── Si es verdadero:"); // Usar caracteres de dibujo de árbol
            printTreeRec(node.left, nivel + 2); // Aumentar indentación para hijos
            
            System.out.println(indent + "  └── Si es falso:");
            printTreeRec(node.right, nivel + 2);
        }
    }

    public TreeNode getRoot() {
        return root;
    }
}