package com.mycompany.c45project;

import java.util.*;
import javax.swing.SwingUtilities;

public class C45Project {

    public static void main(String[] args) {
        SQLLoader loader = new SQLLoader();

        // 1. Configuración para el escenario de Infecciones Respiratorias
        String nombreVista = "V_INFECCION_RESPIRATORIA_DATOS_C45";
        String claseObjetivo = "tipo_infeccion_determinada"; // ('Bacteriana', 'Viral')

        System.out.println("🔄 Cargando datos desde la vista: " + nombreVista + " para predecir '" + claseObjetivo + "'...");
        List<Map<String, String>> datos = loader.cargarDatos(nombreVista);
        
        if (datos == null || datos.isEmpty()) {
            System.out.println("❌ No se cargaron datos. Verifica la vista y la conexión.");
            return;
        }
        System.out.println("✅ Datos cargados: " + datos.size() + " registros.");

        // 2. Pre-procesamiento de Datos y Definición de Atributos
        // Convertir atributos categóricos y de texto en numéricos para la C45DecisionTree actual.
        List<String> atributosOriginales = new ArrayList<>();
        if (!datos.isEmpty()) {
            atributosOriginales.addAll(datos.get(0).keySet());
            atributosOriginales.remove(claseObjetivo); // No incluir la clase objetivo como atributo predictor
        }
        
        List<String> atributosParaArbol = new ArrayList<>();
        List<String> columnasIgnoradasFinalmente = new ArrayList<>(Arrays.asList("id_cita", "id_paciente"));


        for (Map<String, String> fila : datos) {
            // a) Convertir 'paciente_sexo' a numérico (0 o 1)
            String sexo = fila.get("paciente_sexo");
            if (sexo != null) {
                fila.put("paciente_sexo_codificado", sexo.equalsIgnoreCase("M") ? "0" : "1");
            } else {
                fila.put("paciente_sexo_codificado", "0"); // Valor por defecto o para nulos
            }

            // b) Pre-procesar 'motivo_consulta' (TEXTO) para extraer features
            String motivo = fila.get("motivo_consulta");
            if (motivo != null) {
                motivo = motivo.toLowerCase();
                fila.put("sintoma_fiebre", motivo.contains("fiebre") ? "1" : "0");
                fila.put("sintoma_tos_productiva", (motivo.contains("flema") || motivo.contains("productiva")) ? "1" : "0");
                fila.put("sintoma_dolor_garganta", (motivo.contains("garganta") && motivo.contains("dolor")) ? "1" : "0");
                // Puedes añadir más: 'congestion', 'malestar general', etc.
            } else {
                fila.put("sintoma_fiebre", "0");
                fila.put("sintoma_tos_productiva", "0");
                fila.put("sintoma_dolor_garganta", "0");
            }
        }

        // Definir la lista final de atributos para el árbol
        // (columnas de la vista + las nuevas generadas - las originales que se transformaron)
        for (String attrOrig : atributosOriginales) {
            if (attrOrig.equals("paciente_sexo")) {
                atributosParaArbol.add("paciente_sexo_codificado");
            } else if (attrOrig.equals("motivo_consulta")) {
                atributosParaArbol.add("sintoma_fiebre");
                atributosParaArbol.add("sintoma_tos_productiva");
                atributosParaArbol.add("sintoma_dolor_garganta");
                // Añadir aquí los otros 'sintoma_...' que hayas creado
            } else if (!columnasIgnoradasFinalmente.contains(attrOrig)) {
                atributosParaArbol.add(attrOrig);
            }
        }
        // Eliminar duplicados si los hubiera por algún motivo
        atributosParaArbol = new ArrayList<>(new LinkedHashSet<>(atributosParaArbol));


        System.out.println("✅ Atributos para el árbol: " + atributosParaArbol);
        
        // El C45DecisionTree que pasaste no usa el Set de categóricos,
        // asume que todo es parseable a double.
        C45DecisionTree arbol = new C45DecisionTree(); 

        System.out.println("🧠 Entrenando el árbol de decisión C45 para Infecciones Respiratorias...");
        arbol.train(datos, atributosParaArbol, claseObjetivo);
        System.out.println("🌳 Árbol entrenado.");

        System.out.println("\n🌲 Estructura del Árbol Generado (Consola):");
        arbol.printTree();

        final TreeNode rootNodeParaVisualizar = arbol.getRoot(); 

        SwingUtilities.invokeLater(() -> { // Lambda para Runnable
            try {
                System.out.println("\n🎨 Preparando visualización gráfica del árbol...");
                if (rootNodeParaVisualizar != null) {
                    TreeVisualizer.mostrar(rootNodeParaVisualizar);
                    System.out.println("✅ Ventana del árbol de decisión debería estar visible.");
                } else {
                    System.out.println("⚠️ El árbol está vacío (root es null), no se puede visualizar.");
                }
            } catch (Exception e) {
                System.err.println("⚠️ Error crítico al mostrar la ventana gráfica del árbol:");
                e.printStackTrace();
            }
        });
        
        System.out.println("\n🔍 Realizando una predicción de ejemplo para Infección Respiratoria...");
        Map<String, String> nuevaInstanciaRespiratoria = new HashMap<>();
        // Asegúrate que los nombres de atributos coincidan con `atributosParaArbol`
        // y que los valores puedan ser parseados a double.
        nuevaInstanciaRespiratoria.put("paciente_sexo_codificado", "0"); // '0' para M
        nuevaInstanciaRespiratoria.put("edad_paciente_en_cita", "35");
        nuevaInstanciaRespiratoria.put("sintoma_fiebre", "1"); 
        nuevaInstanciaRespiratoria.put("sintoma_tos_productiva", "0");
        nuevaInstanciaRespiratoria.put("sintoma_dolor_garganta", "1");
        nuevaInstanciaRespiratoria.put("wbc_conteo", "15000");
        nuevaInstanciaRespiratoria.put("neutrofilos_porcentaje", "75.0");
        nuevaInstanciaRespiratoria.put("linfocitos_porcentaje", "20.0");
        nuevaInstanciaRespiratoria.put("pcr_valor", "120.5");
        nuevaInstanciaRespiratoria.put("pct_valor", "2.5");
        // No incluir 'motivo_consulta' ni 'paciente_sexo' originales si fueron reemplazados

        System.out.println("  Datos de la nueva instancia para predicción: " + nuevaInstanciaRespiratoria);
        String resultadoPrediccion = arbol.predict(nuevaInstanciaRespiratoria);
        System.out.println("  Resultado de la Predicción para la nueva instancia: " + resultadoPrediccion);
    }
}