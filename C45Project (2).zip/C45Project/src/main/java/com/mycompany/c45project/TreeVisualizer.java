package com.mycompany.c45project;

import javax.swing.*;
import java.awt.*;

public class TreeVisualizer extends JPanel {
    private final TreeNode root;
    private final int nodeWidth = 150;  // Ancho base del nodo
    private final int nodeHeight = 50; // Alto del nodo
    private final int vSpacing = 100;   // Espaciado vertical entre niveles de nodos
    private final int hSpacing = 80;   // Espaciado horizontal mínimo entre nodos hermanos

    public TreeVisualizer(TreeNode root) {
        this.root = root;
        // Un tamaño preferido inicial grande, JScrollPane permitirá el desplazamiento si es necesario
        setPreferredSize(new Dimension(2000, 3000)); 
        setBackground(Color.WHITE); // Fondo blanco para el panel
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g; // Usar Graphics2D para mejor renderizado (antialiasing)
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        if (this.root != null) {
            // Iniciar el dibujo desde el centro superior del panel disponible
            // El offset inicial se basa en el ancho del panel, pero limitado para árboles grandes.
            drawTree(g2d, root, getWidth() / 2, 50, Math.min(getWidth() / 4, 250)); 
        } else {
            g2d.drawString("El árbol está vacío (nodo raíz es null).", 20, 20);
        }
    }

    private void drawTree(Graphics2D g, TreeNode node, int x, int y, int horizontalOffset) {
        if (node == null) return;

        String text;
        if (node.isLeaf()) {
            text = "Clase: " + node.label;
        } else {
            // Formatear el umbral a dos decimales
            text = node.attribute + " \u2264 " + String.format("%.2f", node.threshold); // \u2264 es ≤
        }
        
        FontMetrics fm = g.getFontMetrics();
        int textWidth = fm.stringWidth(text);
        // Ajustar el ancho del nodo si el texto es más largo que el base, más un pequeño padding
        int dynamicNodeWidth = Math.max(nodeWidth, textWidth + 20); 

        // Dibujar el nodo
        g.setColor(new Color(220, 235, 255)); // Un azul claro para el fondo del nodo
        g.fillRect(x - dynamicNodeWidth / 2, y, dynamicNodeWidth, nodeHeight);
        g.setColor(Color.DARK_GRAY); // Un color de borde más suave
        g.drawRect(x - dynamicNodeWidth / 2, y, dynamicNodeWidth, nodeHeight);
        
        // Centrar el texto dentro del nodo
        g.setColor(Color.BLACK);
        int textX = x - textWidth / 2;
        int textY = y + fm.getAscent() + (nodeHeight - fm.getHeight()) / 2;
        g.drawString(text, textX, textY);

        // Si no es una hoja, dibujar las ramas y los nodos hijos
        if (!node.isLeaf()) {
            int childY = y + nodeHeight + vSpacing; // Posición Y para los nodos hijos

            // Nodo izquierdo (condición verdadera: "Sí")
            if (node.left != null) {
                int leftChildX = x - horizontalOffset;
                g.setColor(Color.GRAY);
                g.drawLine(x, y + nodeHeight, leftChildX, childY); // Línea al hijo izquierdo
                // Etiqueta "Sí" en la rama
                g.setColor(Color.BLACK);
                g.drawString("Sí", (x + leftChildX) / 2 - 15, (y + nodeHeight + childY) / 2);
                drawTree(g, node.left, leftChildX, childY, Math.max(horizontalOffset / 2, hSpacing + 10));
            }

            // Nodo derecho (condición falsa: "No")
            if (node.right != null) {
                int rightChildX = x + horizontalOffset;
                g.setColor(Color.GRAY);
                g.drawLine(x, y + nodeHeight, rightChildX, childY); // Línea al hijo derecho
                // Etiqueta "No" en la rama
                g.setColor(Color.BLACK);
                g.drawString("No", (x + rightChildX) / 2 + 5, (y + nodeHeight + childY) / 2);
                drawTree(g, node.right, rightChildX, childY, Math.max(horizontalOffset / 2, hSpacing + 10));
            }
        }
    }

    public static void mostrar(TreeNode root) {
        // Este método será llamado desde SwingUtilities.invokeLater(), por lo que se ejecuta en el EDT
        JFrame frame = new JFrame("Árbol de Decisión C45");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        TreeVisualizer panel = new TreeVisualizer(root);
        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.getViewport().setBackground(Color.WHITE); // Fondo del viewport

        frame.add(scrollPane);
        
        // Establecer un tamaño mínimo para la ventana
        frame.setMinimumSize(new Dimension(600, 400));
        frame.pack(); // Intenta ajustar el tamaño de la ventana al contenido preferido
        
        // Si después de pack() la ventana es muy pequeña o muy grande, puedes establecer un tamaño:
        if (frame.getWidth() < 800 || frame.getHeight() < 600) {
            frame.setSize(Math.max(800, frame.getWidth()), Math.max(600, frame.getHeight()));
        }
        if (frame.getWidth() > 1600 || frame.getHeight() > 1000) { // Limitar tamaño máximo
             frame.setSize(Math.min(1600, frame.getWidth()), Math.min(1000, frame.getHeight()));
        }

        frame.setLocationRelativeTo(null); // Centra la ventana en la pantalla
        frame.setVisible(true);
    }
}